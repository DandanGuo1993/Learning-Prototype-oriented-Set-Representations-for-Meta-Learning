infimnist need to be run in Linux, then run it to generate dataset used in this experiment,  and the data will be stored in "data" file in the parent directory.
Run image_sum.py