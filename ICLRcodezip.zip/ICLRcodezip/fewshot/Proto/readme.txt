Arrange the dataset in the file called filelists following the standard few-shot classification.
Then perform prototype_variants.py