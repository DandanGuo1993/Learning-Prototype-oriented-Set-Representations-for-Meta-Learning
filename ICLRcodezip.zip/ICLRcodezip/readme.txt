Code for 《Learning Prototype-oriented Set Representations for Meta-Learning》, submitted to ICLR 2022


Dependencies:


This code is written in python. To use it you will need:
python3.8.3，
torchvision 0.8.1+cu110，
torch 1.7.0+cu110
A recent version of NumPy and SciPy

You can download and pre-process datasets following our paper.

